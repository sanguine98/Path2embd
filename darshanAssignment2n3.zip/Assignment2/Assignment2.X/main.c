/*
 * File:   main.c
 * Author: admin
 *
 * Created on August 31, 2023, 4:06 PM
 */



#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF //Watchdog timer disabled

 static void init_config(void) {
    LED_ARRAY1_DDR = 0x00;
    LED_ARRAY1 = 0x00;
    init_digital_keypad();
}

void main(void) {
   init_config();
    unsigned long int key,pre_key,i,j,k = 0;
    unsigned long int wait,flag= 0;
    while (1) {
        key = read_digital_keypad(STATE);
        if(key != ALL_RELEASED)
        {
        pre_key = key;
        
        if(pre_key != SW3 || pre_key != SW4 || pre_key != SW1 || pre_key != SW1)
        {
            flag = 0;
        }
        
        }
        if(wait++ == 20000)
        {
            wait = 0;
            if(pre_key == SW1)
            {
                if(pre_key == SW1 && flag == 0)
                {
                    LED_ARRAY1 = 0x00;
                    flag = 1;
                    i = 0;
                    j = 0;
                }
                if(i < 8)
                {
                LED_ARRAY1 = LED_ARRAY1 | (1 << i);
                i++;
                }
                else if (i > 7 && i < 16)
                {
                LED_ARRAY1 = LED_ARRAY1 << 1;
                i++;
                }
                else if (i > 15 && i < 24 )
                {
                LED_ARRAY1 = LED_ARRAY1 | (128 >> j);
                j++;
                i++;
                }
                else if ( i > 23 && i < 32)
                {
                    LED_ARRAY1 = LED_ARRAY1 >> 1;
                    i++;
                }
                else
                {
                    i = 0;
                    j = 0;
                }
            }
            else if(pre_key == SW2)
            {
                if(pre_key == SW2 && flag == 0)
                {
                    LED_ARRAY1 = 0x00;
                    flag = 1;
                    k = 0;
                }
                if(k < 8)
                {
                    LED_ARRAY1 = LED_ARRAY1 | (1 << k);
                    k++;
                }
                else if (k > 7 && k < 16)
                {
                    LED_ARRAY1 = LED_ARRAY1 << 1;
                    k++;
                }
                else
                {
                    k = 0;
                }
            }
            else if (pre_key == SW3)
            {
                if(pre_key == SW3 && flag == 0)
                {
                    LED_ARRAY1 = 0x55;
                    flag = 1;
                }
                LED_ARRAY1 = ~LED_ARRAY1;
            }
            else if (pre_key == SW4)
            {
                if(pre_key == SW4 && flag == 0)
                {
                LED_ARRAY1 = 0x0f;
                flag = 1;
                }
                LED_ARRAY1 = ~LED_ARRAY1;
            }
        }
    }
}

        
        
              